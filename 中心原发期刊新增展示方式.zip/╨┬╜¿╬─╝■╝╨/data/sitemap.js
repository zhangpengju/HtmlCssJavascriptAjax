﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k)]),_(c,l,e,f,g,m,i,[_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q),_(c,r,e,f,g,s)])])]);}; 
var b="rootNodes",c="pageName",d="旧版数据库-首页",e="type",f="Wireframe",g="url",h="旧版数据库-首页.html",i="children",j="旧版数据库-数字期刊库",k="旧版数据库-数字期刊库.html",l="新版数据库",m="新版数据库.html",n="新版数据库-数字期刊库",o="新版数据库-数字期刊库.html",p="新版数据库-数字期刊库-按期刊属性查找",q="新版数据库-数字期刊库-按期刊属性查找.html",r="新版数据库-数字期刊库-原发刊系列",s="新版数据库-数字期刊库-原发刊系列.html";
return _creator();
})();
