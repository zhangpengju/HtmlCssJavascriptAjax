﻿for(var i = 0; i < 59; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u3'] = 'center';u45.tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	SetPanelState('u6', 'pd1u6','none','',500,'none','',500);

}
});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u36'] = 'top';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u52'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	SetPanelState('u6', 'pd0u6','none','',500,'none','',500);

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u35'] = 'center';